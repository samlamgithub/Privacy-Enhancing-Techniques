# Privacy-Enhancing-Techniques
Privacy Enhancing Techniques CW


To Run the program, ensure Python 2.7.6 is installed. And then simply Run
```
python answer.py
```
